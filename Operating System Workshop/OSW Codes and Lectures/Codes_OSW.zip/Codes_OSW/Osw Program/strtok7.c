#include<stdio.h>
#include<string.h>
int main()
{
char str1[]="CSE-IT-CDS-ME";
char str2[]="SUM-ITER-SOA";
char str3[]="OSW-DOS-PIP-CN";
char *token1, *token2, *token3;
//token1=strtok(str1, "-");
token2=strtok(str2, "-");
token1=strtok(str1, "-");
token3=strtok(str3, "-");
while(token2!=NULL)
   {
   printf("Token =%s\n",token2);
   token2=strtok(NULL, "-");
   }
return 0;   
}
