#include<stdio.h>
#include<string.h>
int main()
{
char str[]="CSE-IT-ME-CDS-AI";
char ptr[]="cse-it-me-cds-ai";
char *token, *ptoken;
token=strtok(str, "-");
while(token!=NULL)
   {
   printf("Token=%s\n", token);
   token=strtok(NULL, "-");
   }
ptoken=strtok(ptr, "-");
while(ptoken!=NULL)
   {
   printf("Token=%s\n", ptoken);
   ptoken=strtok(NULL, "-");
   }
return 0;   
}
