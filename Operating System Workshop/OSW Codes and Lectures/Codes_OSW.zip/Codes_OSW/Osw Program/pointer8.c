#include<stdio.h>
int main()
{
int a=10;
int *ptr1, *ptr2;
ptr1=&a;
ptr2=&a;
printf("before addtion\n");
printf("%p\n",ptr2);
ptr2=ptr2+10;
printf("after addition\n");
printf("%p\n",ptr2);
return 0;
}
