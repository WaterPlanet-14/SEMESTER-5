#include<stdio.h>
#include<stdlib.h>
int main()
{
printf("OSW...");
_Exit(0);
printf("CLASS...");
return 0;
}
