#include<stdio.h>
int main()
{
int a=5;
int b=10;
switch(a)
{
case 5:
printf("Value of a is 5\n");
case 10:
switch(b)
{
case 10:
printf("The value of b is 10\n");
}
}
return 0;
}
