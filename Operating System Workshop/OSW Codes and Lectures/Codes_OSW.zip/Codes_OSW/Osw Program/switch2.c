#include<stdio.h>
int main()
{
int x=0;
int y=0;
switch(x>y && x+y>0)
{
case 1:
printf("OSW\n");
break;
case 0:
printf("CLASS\n");
break;
//default:
//printf("Bye \n");
}
return 0;
}
