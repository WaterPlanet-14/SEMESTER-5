#include<stdio.h>
int main()
{int count=10;
int *ptr=&count;
*ptr =20;
printf("New value of count %d\n", count);
*ptr = 2+*ptr;
printf("New value of count %d\n", count);
*ptr=++(*ptr);
printf("New value of count %d\n", count);
return 0;
}
