#include<stdio.h>
void check(int a);
int main()
{
int arr[5], i;
printf("Enter elements\n");
for(i=0;i<5;i++)
   {
    scanf("%d", &arr[i]);
    check(arr[i]);
    }
}
void check(int a)
{
if(a%2==0)
   printf("%d is even\n", a);
   else
   printf("%d is odd\n", a);
}
