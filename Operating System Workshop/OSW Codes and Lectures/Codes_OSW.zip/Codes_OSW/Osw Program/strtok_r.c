#include<stdio.h>
#include<string.h>
int main()
{
char str[]="Lesson-plan-OSW-DOS-PIP-CN-ITC-IDM";
printf("Enter the string\n");
puts(str);
char *token;
char *last;
token=strtok_r(str, "-", &last);
while(token!=NULL)
   {
   printf("Token is %s\n", token);
   printf("\t\tRemaing string is %s\n", last);
   token=strtok_r(NULL,"-",&last);
   }
return 0;   
}
