#include<stdio.h>
#include<string.h>
int main()
{
char str[]="CSE-IT-ME-CDS-AI";
char ptr[]="cse-it-me-cds-ai";
char *token, *ptoken;
token=strtok(str, "-");
ptoken=strtok(ptr, "-");
while(token!=NULL)
   {
   printf("Token=%s\n", token);
   token=strtok(NULL, "-");
   }
return 0;   
}
