#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
void display()
{
printf("Function exit handler\n");
}
int main()
{
int i;
if(atexit(display))
   {
   fprintf(stderr, "failed to install display exit handler\n");
   return 1;
   }
for(int i=0; i<10; i++)
   {
   sleep(5);
   printf("%d\n", i);
   _Exit(0);
   }   
}
