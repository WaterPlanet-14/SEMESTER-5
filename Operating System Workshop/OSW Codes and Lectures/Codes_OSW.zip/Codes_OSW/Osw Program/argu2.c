#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int makeargv(char *, char ***); //function ptototype
int main()
{
char mytest[]="    This is a string";
char **myargv;
int numtoken, i;
numtoken=makeargv(mytest, &myargv);
if(numtoken==-1)
fprintf(stderr, "Faild to create an argument array\n");
else
    {
    for(i=0; i<numtoken; i++)
    printf("Myargv[%d]: %s\n", i,myargv[i]);
    }
return 0;    
}
int makeargv(char *s, char ***argvp)
{
int numtoken=1, i;
char *t, *snew;
*argvp=NULL;
printf("Original string length =%ld\n", strlen(s));
snew=s+strspn(s, " ");
printf("Skipping leading delimiter(if any): string length=%ld\n", strlen(snew));
t=(char *)malloc(sizeof(char)*(strlen(snew)+1));
strcpy(t, snew);
if(strtok(t, " ")!=NULL)
   {
   for(numtoken=1; strtok(NULL, " ")!=NULL; numtoken++);
   }
*argvp=(char **)malloc((numtoken+1)*sizeof(char *));
strcpy(t, snew);
**argvp=strtok(t, " ");
for(i=1;i<numtoken; i++)
*(*argvp+i)=strtok(NULL, " ");
*(*argvp+numtoken)=NULL;
return numtoken;  
}
















