#include<stdio.h>
float calSum(float num[]);
int main()
{
float result, num[]={3.5,8,7.9,10,12.1,15.2};
result=calSum(num); // num array are passed to calSum()
printf("result is =%.2f", result);
return 0;
}
float calSum(float num[])
{
float sum=0.0;
for(int i=0; i<6; ++i)
{
sum +=num[i];
}
return sum;
}
