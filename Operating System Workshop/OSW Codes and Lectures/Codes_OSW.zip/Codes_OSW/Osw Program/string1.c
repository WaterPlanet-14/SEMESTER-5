#include<stdio.h>
int main()
{
char str[]= "OSW CLASS";
printf("%s\n", str);
int length =0;
llength = strlen(str);
printf("The length of string is %d\n", length);
return 0;
}
