#include<stdio.h>
union abc
{
int a;
char b;
float c;
}var;
int main()
{
var.a=10;
var.b='a';
var.c=10.5;
printf("%d\n", var.a);
printf("%c\n",var.b);
printf("%f\n",var.c);
printf("%p\n", &var.a);
printf("%p\n", &var.b);
printf("%p\n", &var.c);
return 0;
}
