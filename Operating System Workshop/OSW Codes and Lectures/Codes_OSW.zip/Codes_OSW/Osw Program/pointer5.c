#include<stdio.h>
int main()
{
int a=10;
char c='A';
int *ptr1=&a;
char *ptr2=&c;
printf("size of integer pointer is %ld\n", sizeof(ptr1));
printf("size of charecter pointer is %ld\n", sizeof(ptr2));
return 0;
}
