# include <stdio.h>
int main()
{
int m,n,p,q,c,d,k,sum=0;
int arr1[10][10], arr2[10][10],mul[10][10];
printf("Enter the row and column of 1st matrix\n");
scanf("%d%d", &m,&n);
printf("Enter the row and column of 2nd matrix\n");
scanf("%d%d", &p,&q);
if(n!=p)
    {
    printf("\n Error input\n");
    }
    else
    {
    printf("Enter the elemrnt of first matrix\n");
    for(c=0;c<m;c++)
     for(d=0;d<n;d++)
     scanf("%d", &arr1[c][d]);
     printf("Enter the elemrnt of second matrix\n");
    for(c=0;c<p;c++)
     for(d=0;d<q;d++)
     scanf("%d", &arr2[c][d]);
//Multiplying operation     
for(c=0; c<m; c++)
     {
      for(d=0;d<q;d++)
      {
      for(k=0;k<p;k++)
       {
       sum=sum+arr1[c][k] *arr2[k][d];
       }
       mul[c][d]=sum;
       sum=0;
      }     
     }
printf("Result matrix is:\n");
for(c=0; c<m;c++)
    {
    for(d=0;d<q;d++)
    printf("%d",mul[c][d]);
    printf("\n");
    }     
    }
return 0;    
}
