#include<stdio.h>
#include<string.h>
int main()
{
char str[]="CSE IT ME CDS AI";
char *token;
const char s[]=" ";
token=strtok(str, s);
while(token !=NULL){
printf("Token =%s\n", token);
token=strtok(NULL, s);
}
return 0;
}
