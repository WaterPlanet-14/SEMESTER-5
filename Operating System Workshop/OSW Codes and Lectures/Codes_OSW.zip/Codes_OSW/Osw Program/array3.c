#include<stdio.h>
void display(int a1, int a2)
{
printf("%d\n", a1);
printf("%d\n", a2);
}
int main()
{
int arr[]={2,3,7,8,10};
display(arr[1], arr[2]); // pass second and third elements of array are display
return 0;
}
