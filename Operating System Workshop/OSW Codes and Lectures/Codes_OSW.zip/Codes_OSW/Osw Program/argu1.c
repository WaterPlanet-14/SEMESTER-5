#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char **makeargv(char *s)
{
int ntoken, i;
char *t, **argvp;
argvp=NULL;
t=(char *) malloc(sizeof(char)*(strlen(s)+1));
strcpy(t,s);
if(strtok(s, " ")!=NULL) //count the number of token into s
   {
   for(ntoken=1; strtok(NULL, " ")!=NULL; ntoken++);
   }
printf("Number of tokens %d\n", ntoken);
argvp=(char **)malloc((ntoken+1)*sizeof(char *));
/* insert pointers to tokens into argument array */
*argvp=strtok(t, " ");
for(i=1; i<ntoken; i++)
   {
   *(argvp+i)=strtok(NULL, " ");
   }   
*(argvp+ntoken)=NULL; //put the final null pointer
return argvp;   
}
char **makeargv(char *);
int main()
{
char s[]= "This is a string";
char **myargv;
myargv=makeargv(s);
if(myargv==NULL)
fprintf(stderr, "Failed to create an argument array\n");
else
   {
   for(int i=0; myargv[i]!=NULL; i++)
   printf("Myargv[%d] : %s\n", i, myargv[i]);
   }
return 0;
}








