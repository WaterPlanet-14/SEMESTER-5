#include<stdio.h>
int main()
{
int a=10, b=5;
int *ptr=&a;
int *ptr1=&b;
*ptr=*ptr+*ptr1;
*ptr1=*ptr-*ptr1;
*ptr1=*ptr-*ptr1;
}
