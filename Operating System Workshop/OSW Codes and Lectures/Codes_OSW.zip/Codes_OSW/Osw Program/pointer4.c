#include<stdio.h>
int main()
{
int a=10;
float b=10.5;
char c='A';
int *ptr1;
float *ptr2;
char *ptr3;
ptr1=&a;
ptr2=&b;
ptr3=&c;
printf("a=%d\n",a);
printf("b=%f\n",b);
printf("c=%c\n",c);
printf("Address of a %p\n", &a);
printf("Address of b %p\n", &b);
printf("Address of c %p\n", &c);
printf("value of address of a %d\n",*(&a));
printf("value of address of b %f\n",*(&b));
printf("value of address of c %c\n",*(&c));
printf("Address of a %p\n", ptr1);
printf("Address of b %p\n", ptr2);
printf("Address of c %p\n", ptr3);
printf("Value of address of a %d\n", *ptr1);
printf("Value of address of b %f\n", *ptr2);
printf("Value of address of c %c\n", *ptr3);
return 0;
}
