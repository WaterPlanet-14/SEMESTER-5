#include<stdio.h>
int main(){
char str1[90];
char str2[90];
gets(str1);
gets(str2);
char *ptr1,*ptr2;
ptr1=&str1;
ptr2=&str2;
int flag=0;
while(*ptr1!=NULL){
if(*ptr1==*ptr2){
ptr1++;
ptr2++;
flag=1;
}
else if(*ptr1!=*ptr2){
printf("Different");
break;
}
}
if(flag==1){
printf("Same");
}
return 0;
}
