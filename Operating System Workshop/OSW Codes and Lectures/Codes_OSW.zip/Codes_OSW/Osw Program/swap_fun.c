#include<stdio.h>
void swap(int a,int b);
int main(void)
{
  int a,b;
  a = 1;
  b =2;
  swap(a,b);
  return 0;
}
void swap(int a,int b)
{
   int c = a;
   a = b;
   b = c;
   printf("Swap Done");
   printf(" A = %d and B = %d" , a,b);
}
