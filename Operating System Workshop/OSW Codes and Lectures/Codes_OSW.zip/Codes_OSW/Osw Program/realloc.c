#include<stdio.h>
#include<stdlib.h>
int main()
{
int i, *ptr,n,m;
printf("Enter size of memory\n");
scanf("%d", &n);
ptr=(int*)malloc(n *sizeof(int));
printf("Allocated memory address is:");
for(i=0; i<n; i++)
printf("%p\n", ptr+i);
printf("Enter new size");
scanf("%d", &m);
ptr=realloc(ptr, m*sizeof(int));
printf("New memory address\n");
for(i=0; i<m; i++)
printf("%p\n", ptr+i);
free(ptr);
return 0;
}
