#include<stdio.h>
int main(){
char str[70];
printf("Enter  string:");
gets(str);
int x=0;
int a=0,d=0,s=0;
while(str[x]!='\0'){
int c=(int)str[x];
if((c>=65&&c<=90) || (c>=97&&c<=122)){
a++;
}
if(c>=48 &&c<=57){
d++;
}
if((c>=32&&c<=47) || (c>=58&&c<=64) || (c>=91&&c<=96) || (c>=123&&c<=126)){
s++;
}
x++;
}
printf("Number of alphabets=%d\n",a);
printf("Number of digits=%d\n",d);
printf("Number of special characters %d",s);
return 0;
}

