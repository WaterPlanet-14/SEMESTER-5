#include<stdio.h>
#include<ctype.h>
int main()
{
char str[50]="OSWCLASS";
char str2[50];
for(int i=0;str[i] !='\0'; i++)
{
str2[i]=tolower(str[i]);
}
printf("input strin %s\n", str);
printf("Lower case string is %s\n", str2);
return 0;
}
