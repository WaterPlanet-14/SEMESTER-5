#include <stdio.h>
int main(){
printf("Enter a string: ");
char str[100];
gets(str);
char copy[100];
char *ptr;
ptr=&str;
int i=0;
while(*ptr!= NULL){
copy[i]=*ptr;
ptr++;
i++;
}
printf("Copy of the string = %s",copy);
return 0;
}
