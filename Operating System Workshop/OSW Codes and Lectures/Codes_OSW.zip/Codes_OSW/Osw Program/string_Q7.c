#include<stdio.h>
int main()
{
char str1[80],str2[80];
int i;

printf("Enter the string");
scanf("%s",str);

for(int i=0
