#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
int main(int argc, char *argv[])
{
pid_t pid=fork();
if(pid<0)
  {
  fprintf(stderr, "fork faild\n");
  return -1;
  }
else if(pid==0)
   {
   printf("I am child an my ID =%ld\n", (long)getpid());
   printf("I am parent an ID =%ld\n", (long)getppid());
   }  
else
   {
   wait(NULL);
   printf("Child Complet the process\n");
   }  
return 0;    
}
