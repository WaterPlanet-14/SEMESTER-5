#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
int main()
{
pid_t childpid;
childpid=fork();
if(childpid==0){
printf("Process ID %d\n",getpid());
}
if(childpid !=wait(NULL)){
printf("Return value of fork=%ld\n", (long)childpid);
printf("Process id %ld\n", (long)getpid());
}
return 0;
}
