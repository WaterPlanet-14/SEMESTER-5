#include<stdio.h>
struct std
{
char name[10];
int roll;
float marks;
char lastname[10];
};
int main()
{
//int size;
//struct std s;
//size=sizeof(s);
printf("size of structure is %d", sizeof(struct std));
return 0;
}
