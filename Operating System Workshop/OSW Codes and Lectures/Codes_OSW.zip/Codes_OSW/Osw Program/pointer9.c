#include<stdio.h>
int main()
{
int a=10;
int b=5;
int *ptr1, *ptr2;
ptr1=&b;
ptr2=&a;
printf("address of ptr1 %u and address of ptr2 %u\n");
a=ptr1-ptr2;
printf("result address is %d\n", a);
return 0;
}
