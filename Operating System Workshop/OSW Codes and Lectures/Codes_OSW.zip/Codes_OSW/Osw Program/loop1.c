#include<stdio.h>
int main()
{
int num;
char ch;
do
{
printf("Enter number\n");
scanf("%d",&num);
if(num==0)
printf("number is zero");
else if(num>0)
printf("number is positive");
else
printf("number is negative");
printf("went to chek again press y/Y");
scanf("%c",&ch);
}
while(ch=='y' || ch=='Y');
return 0;
}
