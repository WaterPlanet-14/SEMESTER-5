#include<stdio.h>
void disply(int m, int n, int arr[m][n])
{
for(int i=0;i<m; i++)
   {
   for(j=0;j<n;j++)
   arr[i][j]=i+j;
   }
}
int main()
{
int m=4;
int n=4;
int arr[m][n];
display(m,n,arr);
for(i=0;i<m;i++)
   {
   for(j=0;j<n;j++)
   printf("%d",arr[i][j]);
   }
   return 0;
}
