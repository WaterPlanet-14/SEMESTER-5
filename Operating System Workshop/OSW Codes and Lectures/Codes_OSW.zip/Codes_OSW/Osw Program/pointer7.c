#include<stdio.h>
int main()
{
//int a=10;
char c='A';
//int *ptr=&a;
char *ptr1=&c;
printf("ptr1=%u\n",ptr1);
ptr1++;
printf("new ptr1 value is %u\n",ptr1);
ptr1--;
printf("updated ptr1 value is %u\n",ptr1);
ptr1--;
printf("updated ptr1 value is %u\n",ptr1);
return 0;
}
