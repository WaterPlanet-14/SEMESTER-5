#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int main(int argc, char *argv[])
{
pid_t childpid=0;
if(argc!=2)
   {fprintf(stderr, "Usage: %s not matching", argv[0]);
   return -1;
   }
int n=atoi(argv[1]);
for(int i=0; i<n; i++)
   {
   if(childpid=fork())
   break;
   }  
sleep(20);   
printf("Process mypid= %ld, Parent id =%ld\n", (long)getpid(), (long)getppid());
return 0;    
}
