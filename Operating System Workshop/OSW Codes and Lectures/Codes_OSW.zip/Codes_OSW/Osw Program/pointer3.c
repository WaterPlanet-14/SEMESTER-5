#include<stdio.h>
int main()
{
int m=10;
int *ab;
printf("Address of m %p\n", &m);
printf("Value of m %d\n", m);
ab=&m;
printf("Address of ab %p\n", ab);
printf("value of ab %d\n", *ab);
m=20;
printf("address of ab %p\n", ab);
printf("value of ab %d\n",*ab);
*ab=7;
printf("Address of m %p\n", &m);
printf("value of m %d\n", m);
return 0;
}
