#include<stdio.h>
int main()
{
int count =10;
int *ptr= &count;
printf("Value of variable count is %d\n", count);
printf("Address of variable count is %p\n", &count);
printf("Value of variable ptr is %p\n", ptr);
printf("Address of the variable ptr is %p\n", &ptr);
printf("Value indirection of ptr is %d\n", *ptr);
return 0;
}
