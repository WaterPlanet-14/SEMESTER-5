#include<stdio.h>
int main()
{
int arr[5]={7,8,1,5,3};
printf("Element in array are:\n");
for(int i =0; i<5; i++)
  {
   printf("%d", arr[i]);   //declariation ,initialization
   }
arr[2] = 10; // update the value
printf("Updated array are:\n");
for(int i=0; i<5; i++)
   { 
   printf("%d", arr[i]);  
    }   
    return 0;
}
