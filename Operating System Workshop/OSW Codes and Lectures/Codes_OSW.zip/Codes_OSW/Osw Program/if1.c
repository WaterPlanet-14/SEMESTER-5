#include<stdio.h>
int main()
{
int x=10;
int y=15;
int z;
if(x>y)
{
printf("x >y\n");
}
else
{
printf("x <y\n");
}
return 0;
}
