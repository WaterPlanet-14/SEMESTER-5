#include<stdio.h>
int numberSum(int n)
{
if (n==0)  //base condition
   {
   return 0;
   }
   int recursion = n+ numberSum(n-1);// recersive case or recersive call
   return recursion;
}
int main()
{
int n=10;
int sum=numberSum(n); // call function
printf("Sum of first %d number is %d\n", n,sum);
return 0;
}
