#include<stdio.h>
#include<string.h>
int main()
{
char *s="---#?This is a ---#?string-----#?";
char *snew;
size_t len;
char *accept="---#?";
printf("Original string =%s\n",s);
len=strspn(s,accept);
printf("Length of initial string s with consist entirely of bytes in accept=%ld\n", len);
snew=s+len;
printf("Now snew= %s\n", snew);
return 0;
}
