#include<stdio.h>
#include<string.h>
int main()
{
char str[]="CSE-IT-ME-CDS-AI";
char *token;
token=strtok(str, "-");
while(token !=NULL){
printf("Token =%s\n", token);
token=strtok(NULL,"-");
}
return 0;
}
