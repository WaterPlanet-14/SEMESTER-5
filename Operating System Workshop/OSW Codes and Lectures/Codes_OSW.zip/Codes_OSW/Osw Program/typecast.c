#include<stdio.h>
int main()
{
int a,b,c;
printf("Enter the values of a,b,c : \n");
scanf("%d%d%d",&a,&b,&c);
a++;
b++;
c++;
int d=a;
int e=b;
int f=c;
printf("The incremented value of a is : %d\n",d);
printf("The incremented value of b is : %d\n",e);
printf("The incremented value of c is : %d\n",f);
return 0;
}
