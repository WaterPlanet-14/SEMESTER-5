# include<stdio.h>
void fact(int a,int *ptr);
void fact(int a,int *ptr){
int factorial=1;
for (int i=1;i<=*ptr;i++){
factorial=factorial*i;
}
printf("Factorial  is %d",factorial);
}
int main(){
int n=5;

int *ptr=&n;
fact(n,ptr);

}

