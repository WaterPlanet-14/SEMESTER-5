#include<stdio.h>
int main(){
char str[100];
printf("Enter string:");
gets(str);
char *ptr;
ptr=&str;
int l=0;
while(*ptr!='\0'){
l++;
ptr++;
}
char *ptr1=&str;
char rev[100];
int i=l-1;
while(*ptr1!='\0'){
rev[i]=*ptr1;
ptr1++;
i--;
}
printf("Reverse of string is: %s\n",rev);
return 0;
}
