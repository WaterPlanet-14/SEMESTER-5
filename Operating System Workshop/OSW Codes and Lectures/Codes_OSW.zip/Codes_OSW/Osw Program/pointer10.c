#include<stdio.h>
int main()
{
int *ptr=NULL;
if(ptr!=NULL)
printf("value of ptr %d\n", *ptr);
else
printf("invalid pointer..");
  return 0;
}
