#include<stdio.h>
#include<math.h>
int main()
{
int num;
float sqrRoot;
long cube;
printf("Enter the number\n");
scanf("%d", &num);
sqrRoot=sqrt(num);
cube=pow(num,3);
printf("Number: %d\n Squre Root is %f\n cube is %ld\n", num,sqrRoot,cube);
return 0;
}
