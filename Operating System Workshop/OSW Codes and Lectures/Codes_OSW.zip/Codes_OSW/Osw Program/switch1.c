#include<stdio.h>
int main()
{
int a=0;
printf("Enter a number\n");
scanf("%d",&a);
switch(a)
{
case 5:
printf("Number is equal to 5 \n");
//break;
case 10:
printf("Number is 10 \n");
//break;
case 15:
printf("Number is 15 \n");
//break;
default:
printf("Number is not 5, 10, 15 \n");
}
return 0;
}
