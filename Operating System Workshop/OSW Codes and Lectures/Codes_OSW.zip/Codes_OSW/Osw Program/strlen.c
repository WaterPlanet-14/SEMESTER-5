#include<stdio.h>
int length(char *ptr)
{
int count =0;
while(*ptr != '\0')
    {
    count++;
    ptr++;
    }
    return count;
}
int main()
{
char str[20];
int l;
printf("Enter the string");
gets(str);
l=length(str);
printf("The length of string is %d\n", l);
return 0;
}
