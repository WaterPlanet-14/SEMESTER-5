#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main(int argc, char *argv[])
{
pid_t childpid=0;
if(argc!=2){
   fprintf(stderr,"Usage %s not matching\n", argv[0]);
   return -1;
   }   
int n=atoi(argv[1]);
for(int i=0; i<n; i++)
   {
if(childpid=fork()<=0)
break;
  }
sleep(30);  
printf("Process: mypid =%ld, Parent ID =%ld\n", (long)getpid(), (long)getppid());
return 0;  
}
