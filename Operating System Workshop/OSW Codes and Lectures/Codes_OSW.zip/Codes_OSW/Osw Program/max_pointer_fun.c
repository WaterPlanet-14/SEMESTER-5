#include <stdio.h>
int greatest(int a,int b){
if(a>b){
printf("Greater:%d",a);

}else{
printf("Greater%d",b );
}
}
int main(){
int a,b;
printf("enter first no.");
scanf("%d",&a);
printf("enter second no.");
scanf("%d",&b);
int *ptr1,*ptr2;
ptr1=&a;
ptr2=&b;
greatest(*ptr1,*ptr2);
return 0;
}

