#include<stdio.h>
int main(){
int r,c;
printf("Enter number of rows in the matrix");
scanf("%d",&r);
printf("Enter number of columns in the matrix");
scanf("%d",&c);
int arr1[r][c];
printf("First matrix\n");
for(int i=0;i<r;i++){
for(int j=0;j<c;j++){
printf("Enter element");
scanf("%d",&arr1[i][j]);
}
}
int arr2[r][c];
printf("Second matrix\n");
for(int i=0;i<r;i++){
for(int j=0;j<c;j++){
printf("Enter element");
scanf("%d",&arr2[i][j]);
}
}
int res[r][c];
for(int i=0;i<r;i++){
for(int j=0;j<c;j++){
res[i][j]=arr1[i][j]+arr2[i][j];
printf("%d\t", res[i][j]);
}
printf("\n");
}
return 0;
}
