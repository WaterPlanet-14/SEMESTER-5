#include<stdio.h>
int main()
{
int i,n,arr[50];
printf("Input the number of elements to store array\n");
scanf("%d", &n);
printf("Input %d number of elements in array\n", n);
for(i=0; i<n; i++)
   {
   printf("Element are %d",i);
   scanf("%d", &arr[i]);
   }
printf("\n The value store into array are\n");
for(i=0; i<n; i++)
  {
printf("%d", arr[i]); 
  } 
printf("\nThe value store in reverse order\n");
for(i=n-1; i>=0; i--)
  {
printf("%d", arr[i]);
printf("\n");
  }  
return 0;   
}
