#include<stdio.h>
int main()
{
int a=10;
float b=10.6;
char c= 'A';
void *ptr;
ptr=&a;
printf("integer value using void pointer is %d\n", *(int*)ptr);
ptr=&b;
printf("float value using void pointer is %f\n", *(float*)ptr);
ptr=&c;
printf("charecter value using void pointer is %c\n", *(char*)ptr);
return 0;
}
