/* program to demonstrate wait and exit */
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
int main()
{
pid_t cpid;
int status=0;
cpid=fork();
if(cpid==-1)
exit(-1);   //terminate child
if(cpid==0)
   {
   printf("Child execute first its pid =%ld\n", (long)getpid());
   sleep(20);
   printf("child pid %ld\n", (long)getpid());
   exit(0);
   }
   else
   {
   printf("Parent execute before wait\n");
   cpid=wait(NULL);
   printf("cpid return is (%d)\n", cpid);
   printf("status is %d\n", status);
   }
   return 0;    
}
