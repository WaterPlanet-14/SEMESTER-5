/* Program to demonstrate waitpid and exit */

#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<unistd.h>
int main()
{
pid_t cpid;
pid_t cpid2;
pid_t ret_pid;
int status=0;
cpid=fork();
if(cpid==-1)
exit(-1);   //terminate child depending on use case
if(cpid==0)
   {
   printf("Child-1 executing is pid=(%d)\n", getpid());
   sleep(15);
   printf("child-1 exited\n");
   exit(2);   
   }
   else
   {
   cpid2=fork();
   if(cpid2==-1)
   {
   exit(-1);
   }
   if(cpid2==0)
   {
   printf("Child-2 executeing its pid (%d)\n", getpid());
   sleep(15);
   printf("child-2 exited\n");
   exit(1);
   }
printf("Parent executing before wait() parent id is (%d)\n", getpid());
ret_pid=waitpid(cpid2, &status, 0);
printf("cpid returned is (%d)\n", ret_pid);
printf("status is (%d)\n", status);
ret_pid=waitpid(cpid, &status, 0);
printf("cpid returned is (%d)\n", ret_pid);
printf("Status is (%d)\n", status);
printf("Parent exited");
   }
   return 0;
}
