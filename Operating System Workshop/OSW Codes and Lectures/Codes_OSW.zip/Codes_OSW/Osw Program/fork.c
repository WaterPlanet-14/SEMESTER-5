#include<stdio.h>
#include<unistd.h>
int main()
{
int p;
p=0;
fork();
p=1;
printf("I am process %ld and my p is %d\n", (long) getpid(),p);
return 0;
}
