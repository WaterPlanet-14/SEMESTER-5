#include<stdio.h>
int main()
{
int arr[]={1,2,3,4,5,6};
int *ptr;
for(ptr=&arr[0]; ptr<=&arr[5]; ptr++)
printf("%d\t", *ptr);
return 0;
}
