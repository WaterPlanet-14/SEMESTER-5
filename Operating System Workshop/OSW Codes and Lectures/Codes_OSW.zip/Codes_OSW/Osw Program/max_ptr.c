#include <stdio.h>
int main () {
int first;
int second;
int max;
int *p1;
int *p2;
int *p3;
printf("ENTER THE FIRST NUMBER:\n");
scanf("%d",&first);
printf("ENTER THE SECOND NUMBER:\n");
scanf("%d",&second);
p1=&first;
p2=&second;
p3=&max;
if(*p1>*p2)
  max=*p1;
else
max=*p2;
printf("THE MAXIMUM NUMBER IS : %d\n",max);
return 0;
}
