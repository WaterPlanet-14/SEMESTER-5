#include<stdio.h>
int addNumbers(int a, int b); // function prototype
int main()
{
int x, y, sum;
printf("Enter two numbers\n");
scanf("%d%d", &x,&y);
sum=addNumbers(x,y);  //function call
printf("The result is %d\n", sum);
return 0;
}
int addNumbers(int a, int b)  // function difinition
{
int result;
result = a+ b;
return result;
}
