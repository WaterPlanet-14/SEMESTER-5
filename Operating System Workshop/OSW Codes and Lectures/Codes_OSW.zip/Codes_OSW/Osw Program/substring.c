#include<stdio.h>
#include<string.h>
int main()
{
char result[10];
char str[15]="Jan. 30, 1997";
strncpy(result,str,9);
result[9]='\0';
printf("Substring %s\n", result);
return 0;
}
