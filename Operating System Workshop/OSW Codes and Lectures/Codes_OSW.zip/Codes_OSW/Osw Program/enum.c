#include<stdio.h>
enum day{Sunday=5, Monday=9, Tuesday, Wednessday, Thursday, Friday, Saturday};
int main()
{
enum day today;
today=Friday;
printf("today =%d\n", today);
return 0;
}
