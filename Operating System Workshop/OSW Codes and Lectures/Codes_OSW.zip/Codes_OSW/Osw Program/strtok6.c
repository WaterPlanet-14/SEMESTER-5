#include<stdio.h>
#include<string.h>
int main()
{
char str[]="CSE-IT-ME-CDS-AI";
char ptr[]="cse-it-me-cds-ai";
char *token, *ptoken,*sptr1, *sptr2;
token=strtok_r(str, "-", &sptr1);
ptoken=strtok_r(ptr, "-", &sptr2);
while(token !=NULL)
   {
   printf("Token is %s\n", token);
   token=strtok_r(NULL,"-", &sptr1);
   }
while(ptoken !=NULL)
   {
   printf("Token is %s\n", ptoken);
   ptoken=strtok_r(NULL,"-", &sptr2);
   }  
return 0;    
}
