#include<stdio.h>
int main()
{
int a,b,sum;
printf("Enter two numbers\n");
scanf("%d%d", &a,&b);
sum=addNumbers(&a, &b);
printf("result is %d\n", sum);
return 0;
}
int addNumbers(int *a1, int *b1)
{
int sum;
sum = *a1 + *b1;
return sum;
}
