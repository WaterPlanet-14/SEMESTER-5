#include<stdio.h>
struct abc
{
int a;
char b;
}var;
int main()
{
var.a=10;
printf("%d\n", var.a);
printf("%c\n",var.b);
printf("%p\n", &var.a);
printf("%p\n", &var.b);
return 0;
}
