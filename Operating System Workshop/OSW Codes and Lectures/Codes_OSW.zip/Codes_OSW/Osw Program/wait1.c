#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
int main()
{
pid_t childpid;
childpid=fork();
if(childpid==0)
printf("Inside child\n");
else
   {
   wait(NULL);
   printf("In parent\n");
   }
return 0;   
}
