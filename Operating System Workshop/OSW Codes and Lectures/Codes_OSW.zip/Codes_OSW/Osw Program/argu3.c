#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int makeargv(const char *s, const char * delimiter, char *** argvp);
int main(int argc, char *argv[])
{
char delim[]=" : ";
int numtoken, i;
char **myargv;
if(argc!=2)
   {
   fprintf(stderr, "usage: %s string\n", argv[0]);
   return -1;
   }
if((numtoken=makeargv(argv[1], delim, &myargv))==-1)
  {
  fprintf(stderr, "faild to create argument array %s\n", argv[1]);
  return -1;
  }   
printf("Original array :\n");
for(i=0; i<numtoken;i++)
printf("%d: %s\n", i, myargv[i]);
return 0;
}
int makeargv(const char *s, const char *delimiter, char ***argvp)
{
int numtoken=1, i;
char *t;
const char *snew;
if((s==NULL) || (delimiter==NULL) || (argvp==NULL))
    {
    return -1;
    }
*argvp=NULL;
snew=s+strspn(s, delimiter);
t=(char *)malloc(sizeof(char)*strlen(snew)+1);
strcpy(t,snew);
if(strtok(t,delimiter)!=NULL)
    {
    for(numtoken=1; strtok(NULL, " ")!=NULL; numtoken++);
    }    
*argvp=(char **)malloc((numtoken+1)*sizeof(char *));
strcpy(t,snew);
**argvp=strtok(t,delimiter);
for(i=1 ;i<numtoken; i++)
*(*argvp+i)=strtok(NULL, " ");
*(*argvp+numtoken)=NULL;
return numtoken;    
}














