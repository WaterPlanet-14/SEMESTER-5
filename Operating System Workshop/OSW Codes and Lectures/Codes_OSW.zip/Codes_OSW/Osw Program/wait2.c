#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
int main()
{
pid_t first,second;
pid_t returnR;
int sum;
first=fork();
if(first>0)
   {
   printf("Parent section\n");
   returnR=wait(NULL);
   printf("After the child process termination wait return value=%ld\n",(long)returnR);
   }
if(first==0)
   {
   printf("The child process id %ld\n", (long)getpid());
   sum=5+7;
   printf("Sum is %d", sum);
   printf("Child complete\n");
   }
return 0;   
}
