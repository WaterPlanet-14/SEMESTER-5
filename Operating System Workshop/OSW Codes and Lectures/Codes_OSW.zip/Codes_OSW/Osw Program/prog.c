#include<stdio.h>
int a,b,c;
char ch;
int main()
{
return 0;
}
