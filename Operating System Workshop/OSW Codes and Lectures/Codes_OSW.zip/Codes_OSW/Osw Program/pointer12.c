#include<stdio.h>
void display(int *arr, int m,int n)
{
int i,j;
for(i=0; i<m; i++)
{
for(j=0; j<n; j++)
{
printf("%d",*((arr+i *n)+j));
}
printf("\n");
}
}
int main()
{int m=3;
int n=2;
int arr[][2]={{1,2},{3,4},{5,6}};
display((int *)arr, m,n);
return 0;
}
