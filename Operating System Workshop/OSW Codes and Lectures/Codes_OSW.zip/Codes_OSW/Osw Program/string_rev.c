#include<stdio.h>
int main()
{
char str1[100], str2[100];
int begin, end, count;
count=0;
printf("Input string\n");
gets(str1);
while(str1[count]!='\0')
count++;
end=count-1;
for(begin=0; begin<count;begin++)
{
str2[begin]=str1[end];
end--;
} 
str2[begin]='\0';
printf("new string is %s\n", str2);
return 0;
}
