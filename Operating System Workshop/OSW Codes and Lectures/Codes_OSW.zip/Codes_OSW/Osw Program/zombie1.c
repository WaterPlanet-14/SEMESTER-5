#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/wait.h>
int main()
{
pid_t childpid;
childpid=fork();
if(childpid==-1){
printf("Error\n");
return -1;
    }
else if(childpid==0)
     {
     printf("I am child, my Process ID %ld\n", (long)getpid());
     exit(0);
     } 
else 
    {
    printf("I am parent, My PID= %ld\n", (long)getpid());
    sleep(30);
    wait(NULL);
    exit(0);
    }    
return 0;       
}
