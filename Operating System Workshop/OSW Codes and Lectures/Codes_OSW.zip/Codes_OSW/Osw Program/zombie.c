#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main()
{
pid_t childpid;
childpid=fork();
if(childpid)
sleep(20);
else
printf("I am child and my ID= %ld, and my parent ID=%ld\n", (long)getpid(), (long)getppid());
exit(0);
return 0;
}
