#include<stdio.h>
#include<string.h>
int main(){
char str[100];
int i,totalword;
totalword=1;
printf("enter any string: ");
gets(str);
for(i=0; str[i]!='\0';i++){
if(str[i]==' '){
totalword++;
}
}
printf("total number of word in this string: %d\n",totalword);
return 0;
}
