#include <stdio.h>
int sqsum(int arr[], int size);
int main(){
printf("Enter size of array");
int size;
scanf("%d",&size);
int arr[size];
for(int i=0;i<size;i++){
printf("Enter element:");
scanf("%d", &arr[i]);
}
int res=sqsum(arr,size);
printf("Result=%d",res);
return 0;
}
int sqsum(int arr[], int size){
int sum=0;
for(int i=0;i<size;i++){
sum+=arr[i]*arr[i];
}
return sum;
}
