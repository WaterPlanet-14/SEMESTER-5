#include <stdio.h>
void main() {
	int x=5;
	int y=10;
	printf("%d %d", x, y);

}

