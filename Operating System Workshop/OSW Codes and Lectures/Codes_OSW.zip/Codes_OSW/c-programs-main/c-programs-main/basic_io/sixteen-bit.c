#include <stdint.h>
# include <stdio.h>
#include <math.h>

int main(){
  unsigned short x = (int) pow(2, 16)-1;
  printf("%i", x*2);
}
