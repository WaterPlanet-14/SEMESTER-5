# include <stdio.h>
void main(){
	int a = 15;
	int b = 8;
	int intDiv = a/b;
	float floatDiv = (float)a/b;
	printf("IntDiv = %d, floatDiv = %f\n", intDiv, floatDiv);
}
