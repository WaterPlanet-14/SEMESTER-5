#include <stdio.h>
#include <unistd.h>
int main() {
  // fork();
  // fork() && fork() || fork();
  // fork();
  // printf("Done\n");
  int a = 5;
  // a =
}