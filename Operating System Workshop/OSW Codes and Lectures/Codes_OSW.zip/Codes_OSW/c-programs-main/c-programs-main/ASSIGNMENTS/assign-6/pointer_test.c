#include <math.h>
#include <stdio.h>

int main() { printf("pow: %f\n", pow(5, 3)); }