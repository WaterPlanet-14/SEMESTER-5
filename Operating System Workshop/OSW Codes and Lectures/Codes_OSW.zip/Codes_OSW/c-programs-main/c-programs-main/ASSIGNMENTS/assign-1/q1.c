#include <stdio.h>

int main()
{
  float a = 1.0, b = 2.0, c = 3.0, d = 4.0;
  // printf("%f", a - b / c * d);
  int flag = 0;
  printf("%f", c + d / b <= 3.5);
  if (flag)
  {
  }
  else
  {
    printf("World");
  }
}