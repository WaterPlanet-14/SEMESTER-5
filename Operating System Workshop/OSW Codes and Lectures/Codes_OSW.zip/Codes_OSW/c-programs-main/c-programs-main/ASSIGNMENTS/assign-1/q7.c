#include <stdio.h>

int main(){
  int ascii = (int)'?';
  printf("%d %c %d\n",ascii,'?','?');

}
