int count;
void write_extern() { count += 2; }