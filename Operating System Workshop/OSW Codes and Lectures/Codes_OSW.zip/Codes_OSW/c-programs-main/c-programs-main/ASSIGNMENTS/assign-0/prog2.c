# include <stdio.h>
int main(void){
  float i=2.0, j=3.0;
  printf("%d==%.2f==%.2lf\n", 5, 55.5, 55.5);
  printf("%i==%.2e==%.3E\n", 5, 555.5, 123.45);
  printf("%o==%g==%G\n", 9, 555.5, 123.45);
}
