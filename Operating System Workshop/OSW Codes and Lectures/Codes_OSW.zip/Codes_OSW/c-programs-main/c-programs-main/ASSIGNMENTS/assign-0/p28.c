# include <stdio.h>

int main(){
  int i=10,m=10;
  printf("%d",printf("%d %d ",i,m));
  return 0;
}
