# include <stdio.h>

void strInput(){
}

int main(){
  // char a,b,c;
  // scanf("%c %c %c",&a,&b,&c);
  // printf("%c %c %c\n",a,b,c);
  int num1=0,num2=0,num3=0;
  printf("Enter a number:");
  scanf("%2d%3d%4d",&num1,&num2,&num3);
  printf("%d %d %d",num1,num2,num3);
  return 0;
}
