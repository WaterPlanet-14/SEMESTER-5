# include <stdio.h>

void strInput(){
  char str1[3], str2[3], str[3];
  scanf("%s",&str);
  printf("%s\n",str);
}

int main(){
  // char a,b,c;
  // scanf("%c %c %c",&a,&b,&c);
  // printf("%c %c %c\n",a,b,c);
  strInput();
  return 0;
}
