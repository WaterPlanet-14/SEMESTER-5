# include <stdio.h>
int main(void){
	printf("This is my first C program!\nI know:\n	where to write c program,\n	how to save c program!\nTo compile- (1) gcc filename.c\n	(2) gcc filename.c -o  filename.o\nTo run- (1)	./a.out\n		./my.out\n------------------\nAble to run successfully !!!");
}
